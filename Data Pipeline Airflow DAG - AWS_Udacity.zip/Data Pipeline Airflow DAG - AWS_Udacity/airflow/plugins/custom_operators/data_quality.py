from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from airflow.providers.postgres.hooks.postgres import PostgresHook

class DataQualityOperator(BaseOperator):

    ui_color = '#89DA59'

    @apply_defaults
    def __init__(self,
                 redshift_conn_id="",
                 dq_checks=None,
                 *args, **kwargs):

        super(DataQualityOperator, self).__init__(*args, **kwargs)
        
        # Map parameters to class attributes
        self.redshift_conn_id = redshift_conn_id
        self.dq_checks = dq_checks or []

    def execute(self, context):
        self.log.info("Grabbing Redshift connection...")
        redshift = PostgresHook(postgres_conn_id=self.redshift_conn_id)

        if len(self.dq_checks) <= 0:
            self.log.info("No data quality checks provided. Skipping...")
            return

        error_count = 0
        failing_tests = []

        self.log.info("Starting data quality checks...")
        
        # Loop through each check provided in the DAG
        for check in self.dq_checks:
            sql = check.get('check_sql')
            exp_result = check.get('expected_result')
            
            # Execute the query in Redshift
            records = redshift.get_records(sql)
            
            # Check if the query returned no results at all
            if len(records) < 1 or len(records[0]) < 1:
                self.log.error(f"Data quality check failed. '{sql}' returned no results.")
                error_count += 1
                failing_tests.append(sql)
                continue
                
            # Compare the actual result to the expected result
            num_records = records[0][0]
            if num_records != exp_result:
                self.log.error(f"Data quality check failed. Expected {exp_result} but got {num_records} for query: {sql}")
                error_count += 1
                failing_tests.append(sql)
            else:
                self.log.info(f"Data quality check passed! Expected {exp_result} and got {num_records}.")

        # If any tests failed, raise an exception to fail the task in Airflow
        if error_count > 0:
            self.log.info('The following tests failed:')
            self.log.info(failing_tests)
            raise ValueError(f"{error_count} Data Quality check(s) failed.")
        
        self.log.info("All data quality checks passed successfully!")