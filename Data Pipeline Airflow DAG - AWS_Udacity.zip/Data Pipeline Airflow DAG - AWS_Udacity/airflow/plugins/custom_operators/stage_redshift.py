from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.providers.amazon.aws.hooks.base_aws import AwsBaseHook

class StageToRedshiftOperator(BaseOperator):
    ui_color = '#358140'
    
    # This tells Airflow to process Jinja templates in the s3_key parameter
    template_fields = ("s3_key",)

    # The dynamic SQL COPY command template
    copy_sql = """
        COPY {}
        FROM '{}'
        ACCESS_KEY_ID '{}'
        SECRET_ACCESS_KEY '{}'
        REGION '{}'
        FORMAT AS JSON '{}'
    """

    @apply_defaults
    def __init__(self,
                 redshift_conn_id="",
                 aws_credentials_id="",
                 table="",
                 s3_bucket="",
                 s3_key="",
                 region="us-east-1",   # Updated to match your AWS region
                 json_path="auto",
                 *args, **kwargs):
        super(StageToRedshiftOperator, self).__init__(*args, **kwargs)
        
        # Map parameters to class attributes
        self.redshift_conn_id = redshift_conn_id
        self.aws_credentials_id = aws_credentials_id
        self.table = table
        self.s3_bucket = s3_bucket
        self.s3_key = s3_key
        self.region = region
        self.json_path = json_path

    def execute(self, context):
        self.log.info("Grabbing AWS credentials and Redshift connection...")
        
        # Depending on your Airflow version, if this AwsBaseHook throws an error, 
        # try changing the import to: from airflow.contrib.hooks.aws_hook import AwsHook
        aws_hook = AwsBaseHook(self.aws_credentials_id, client_type='s3')
        credentials = aws_hook.get_credentials()
        redshift = PostgresHook(postgres_conn_id=self.redshift_conn_id)

        self.log.info(f"Clearing data from destination Redshift table: {self.table}")
        redshift.run(f"DELETE FROM {self.table}")

        self.log.info("Formatting S3 path and executing COPY command...")
        
        # context lets Airflow dynamically format the key (e.g., if you used timestamps)
        rendered_key = self.s3_key.format(**context)
        s3_path = f"s3://{self.s3_bucket}/{rendered_key}"

        # Inject the variables into the COPY SQL string
        formatted_sql = StageToRedshiftOperator.copy_sql.format(
            self.table,
            s3_path,
            credentials.access_key,
            credentials.secret_key,
            self.region,
            self.json_path
        )
        
        # Run the command
        redshift.run(formatted_sql)
        self.log.info(f"Successfully staged data from {s3_path} to {self.table}")