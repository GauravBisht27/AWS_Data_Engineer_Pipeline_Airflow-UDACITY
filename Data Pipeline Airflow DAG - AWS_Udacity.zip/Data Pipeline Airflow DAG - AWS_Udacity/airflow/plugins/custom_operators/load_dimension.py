from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from airflow.providers.postgres.hooks.postgres import PostgresHook

class LoadDimensionOperator(BaseOperator):

    ui_color = '#80BD9E'

    @apply_defaults
    def __init__(self,
                 redshift_conn_id="",
                 table="",
                 sql_query="",
                 append_only=False, # This is the toggle required by the rubric
                 *args, **kwargs):

        super(LoadDimensionOperator, self).__init__(*args, **kwargs)
        
        # Map parameters to class attributes
        self.redshift_conn_id = redshift_conn_id
        self.table = table
        self.sql_query = sql_query
        self.append_only = append_only

    def execute(self, context):
        self.log.info(f"Grabbing Redshift connection for {self.table}...")
        redshift = PostgresHook(postgres_conn_id=self.redshift_conn_id)

        # Check if we need to clear the table first (Truncate-Insert mode)
        if not self.append_only:
            self.log.info(f"Append-only is False. Clearing existing data from {self.table}...")
            redshift.run(f"DELETE FROM {self.table}")
            
        self.log.info(f"Loading data into dimension table: {self.table}")
        
        # Dynamically format the INSERT statement
        formatted_sql = f"INSERT INTO {self.table} {self.sql_query}"
        
        # Execute the query
        redshift.run(formatted_sql)
        
        self.log.info(f"Successfully loaded data into dimension table: {self.table}")