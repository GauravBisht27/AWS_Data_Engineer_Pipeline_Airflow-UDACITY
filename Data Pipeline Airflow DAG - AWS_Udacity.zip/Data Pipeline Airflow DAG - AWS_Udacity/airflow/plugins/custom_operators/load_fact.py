from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from airflow.hooks.postgres_hook import PostgresHook

class LoadFactOperator(BaseOperator):

    ui_color = '#F98866'

    @apply_defaults
    def __init__(self,
                 redshift_conn_id="",
                 table="",
                 sql_query="",
                 *args, **kwargs):

        super(LoadFactOperator, self).__init__(*args, **kwargs)
        
        # Map parameters to class attributes
        self.redshift_conn_id = redshift_conn_id
        self.table = table
        self.sql_query = sql_query

    def execute(self, context):
        self.log.info(f"Grabbing Redshift connection for {self.table}...")
        redshift = PostgresHook(postgres_conn_id=self.redshift_conn_id)

        self.log.info(f"Loading data into fact table: {self.table}")
        
        # Fact tables are append-only. We dynamically format the INSERT statement.
        formatted_sql = f"INSERT INTO {self.table} {self.sql_query}"
        
        # Execute the query
        redshift.run(formatted_sql)
        
        self.log.info(f"Successfully loaded data into fact table: {self.table}")